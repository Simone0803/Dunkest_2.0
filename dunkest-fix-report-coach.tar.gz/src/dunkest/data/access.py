from __future__ import annotations

from copy import copy
from datetime import datetime, timezone
import logging
import warnings
from pathlib import Path

import pandas as pd
import yaml

from dunkest.config import Settings
from dunkest.data.cache import cache_valid, read_cache_metadata, read_parquet, write_parquet
from dunkest.data.dunkest import client as dk_module
from dunkest.data.dunkest.fixtures import get_fixture_mapping
from dunkest.data.nba import collector as nba
from dunkest.names import player_key
from dunkest.rules.coach import coach_points_from_game

PLUSVALENZA_SAMPLE_GAMEWEEKS = tuple(range(1, 92))
logger = logging.getLogger(__name__)


def _processed(settings: Settings, name: str) -> Path:
    return settings.data_path / "processed" / name


def _check_live_market_freshness(settings: Settings, path: Path) -> None:
    """Reject timestamped Lineups exports that are too old; warn on legacy CSVs."""
    metadata = read_cache_metadata(path)
    if metadata is None:
        warnings.warn(
            f"Lineups market {path} has no freshness metadata; regenerate it to verify its age.",
            RuntimeWarning,
            stacklevel=2,
        )
        return
    try:
        fetched_at = datetime.fromisoformat(str(metadata["fetched_at"]))
        if fetched_at.tzinfo is None:
            fetched_at = fetched_at.replace(tzinfo=timezone.utc)
    except (KeyError, TypeError, ValueError):
        raise RuntimeError(f"Lineups market metadata is invalid: {path}") from None
    age_hours = (datetime.now(timezone.utc) - fetched_at.astimezone(timezone.utc)).total_seconds() / 3600
    if age_hours < 0 or age_hours > settings.market_cache_max_age_hours:
        raise RuntimeError(
            f"Lineups market is stale ({age_hours:.1f}h; limit "
            f"{settings.market_cache_max_age_hours:.1f}h): {path}. Refresh the Lineups scrape."
        )


def save_player_credit_snapshot(
    settings: Settings, market: pd.DataFrame, gameweek: int
) -> None:
    required = {"player_name", "cr"}
    if not required.issubset(market.columns):
        return
    columns = [
        column
        for column in (
            "player_name", "team_code", "role", "cr", "official_plusvalenza",
            "lineup_group", "status", "dunkest_turn",
        )
        if column in market.columns
    ]
    snapshot = market[columns].copy()
    snapshot["cr"] = pd.to_numeric(snapshot["cr"], errors="coerce")
    if "official_plusvalenza" in snapshot:
        snapshot["official_plusvalenza"] = pd.to_numeric(
            snapshot["official_plusvalenza"], errors="coerce"
        )
    snapshot = snapshot.dropna(subset=["player_name", "cr"]).drop_duplicates(
        "player_name", keep="last"
    )
    snapshot["gameweek"] = int(gameweek)
    path = _processed(
        settings, f"player_credits_{settings.season_id}_gw{gameweek}.parquet"
    )
    write_parquet(
        snapshot,
        path,
        source="dunkest_market_credit_snapshot",
        season_id=settings.season_id,
        gameweek=gameweek,
        dunkest_turn=settings.target_dunkest_turn,
    )


def add_previous_credit_change(
    settings: Settings, market: pd.DataFrame, gameweek: int
) -> pd.DataFrame:
    out = market.copy()
    out["cr_change_last_gameweek"] = float("nan")
    if gameweek <= 1 or not {"player_name", "cr"}.issubset(out.columns):
        return out
    previous_path = _processed(
        settings, f"player_credits_{settings.season_id}_gw{gameweek - 1}.parquet"
    )
    previous = read_parquet(previous_path)
    if previous is None or not {"player_name", "cr"}.issubset(previous.columns):
        return out
    previous = previous.copy()
    previous["key"] = previous["player_name"].map(player_key)
    previous_cr = pd.to_numeric(previous.drop_duplicates("key", keep="last").set_index("key")["cr"], errors="coerce")
    current_cr = pd.to_numeric(out["cr"], errors="coerce")
    out["cr_change_last_gameweek"] = out["player_name"].map(player_key).map(previous_cr)
    out["cr_change_last_gameweek"] = current_cr - out["cr_change_last_gameweek"]
    return out


def add_official_plusvalenza(
    market: pd.DataFrame, gameweek_stats: pd.DataFrame | None
) -> pd.DataFrame:
    out = market.copy()
    out["official_plusvalenza"] = float("nan")
    if (
        gameweek_stats is None
        or gameweek_stats.empty
        or not {"player_name", "plus"}.issubset(gameweek_stats.columns)
        or "player_name" not in out
    ):
        return out
    weekly = gameweek_stats[["player_name", "plus"]].copy()
    weekly["key"] = weekly["player_name"].map(player_key)
    plus_by_player = pd.to_numeric(
        weekly.drop_duplicates("key", keep="last").set_index("key")["plus"],
        errors="coerce",
    )
    out["official_plusvalenza"] = out["player_name"].map(player_key).map(plus_by_player)
    return out


NBA_TEAM_CODES = {
    "ATL", "BOS", "BKN", "BRK", "CHA", "CHO", "CHI", "CLE", "DAL", "DEN",
    "DET", "GSW", "GS", "HOU", "IND", "LAC", "LAL", "MEM", "MIA", "MIL",
    "MIN", "NOP", "NO", "NYK", "OKC", "ORL", "PHI", "PHX", "POR", "SAC",
    "SAS", "TOR", "UTA", "WAS", "NJN", "NOH", "NOK", "SEA",
}


def get_plusvalenza_history(
    settings: Settings,
    season_id: str | None = None,
    force_refresh: bool = False,
    through_gameweek: int | None = None,
) -> pd.DataFrame:
    """Download official NBA PDK/PLUS outcomes from multiple Dunkest seasons.

    Dunkest season IDs are shared across competitions and are not consecutive
    NBA years. Candidate seasons are therefore verified using NBA team codes
    in the official statistics response before they enter the training set.
    """
    active_season = str(season_id or settings.season_id)
    through_gameweek = settings.target_gameweek - 1 if through_gameweek is None else int(through_gameweek)
    if through_gameweek < 0:
        raise ValueError("through_gameweek must be nonnegative")
    try:
        active_number = int(active_season)
    except ValueError as exc:
        raise ValueError(f"Dunkest season id must be numeric, got {active_season!r}") from exc
    latest_candidate = active_number if through_gameweek > 0 else active_number - 1
    active_cutoff = min(through_gameweek, max(PLUSVALENZA_SAMPLE_GAMEWEEKS))
    anchor = _processed(
        settings,
        f"plusvalenza_history_multiseason_{active_season}_pre_gw{through_gameweek}_{settings.capital_gain_history_seasons}y_nba_v3.parquet",
    )
    if not force_refresh and cache_valid(anchor):
        cached = read_parquet(anchor)
        if cached is not None:
            return cached

    columns = ["player_name", "team_code", "role", "cr", "pdk", "plus", "min", "starter", "gameweek", "season_id"]
    selected_seasons: list[str] = []
    first_weeks: dict[str, pd.DataFrame] = {}
    for candidate in range(latest_candidate, 0, -1):
        prior_settings = copy(settings)
        prior_settings.season_id = str(candidate)
        try:
            first_week = dk_module.fetch_dunkest_gameweek_players(prior_settings, 1)
        except Exception as exc:
            logger.debug("Dunkest season %s unavailable during NBA history discovery: %s", candidate, exc)
            continue
        if first_week.empty or not {"player_name", "team_code", "cr", "pdk", "plus"}.issubset(first_week.columns):
            continue
        nba_week = first_week.loc[first_week["team_code"].astype(str).str.upper().isin(NBA_TEAM_CODES)].copy()
        if nba_week.empty:
            continue
        selected_seasons.append(str(candidate))
        first_weeks[str(candidate)] = nba_week
        if len(selected_seasons) >= settings.capital_gain_history_seasons:
            break

    samples: list[pd.DataFrame] = []
    for historical_season in selected_seasons:
        cutoff = active_cutoff if historical_season == active_season and through_gameweek > 0 else 91
        season_path = _processed(settings, f"plusvalenza_history_nba_{historical_season}_through_gw{cutoff}_v3.parquet")
        cached_season = None if force_refresh or not cache_valid(season_path) else read_parquet(season_path)
        if cached_season is not None and not cached_season.empty:
            samples.append(cached_season)
            continue
        prior_settings = copy(settings)
        prior_settings.season_id = historical_season
        season_samples: list[pd.DataFrame] = []
        consecutive_misses = 0
        for gameweek in range(1, cutoff + 1):
            if gameweek == 1:
                weekly = first_weeks[historical_season]
            else:
                try:
                    weekly = dk_module.fetch_dunkest_gameweek_players(prior_settings, gameweek)
                except Exception as exc:
                    if gameweek in (2, 46, 91):
                        logger.warning("Dunkest PLUS history unavailable for NBA season %s GW%s: %s", historical_season, gameweek, exc)
                    consecutive_misses += 1
                    if consecutive_misses >= 3:
                        break
                    continue
                if weekly.empty or not {"player_name", "team_code", "cr", "pdk", "plus"}.issubset(weekly.columns):
                    consecutive_misses += 1
                    if consecutive_misses >= 3:
                        break
                    continue
                weekly = weekly.loc[weekly["team_code"].astype(str).str.upper().isin(NBA_TEAM_CODES)].copy()
                if weekly.empty:
                    consecutive_misses += 1
                    if consecutive_misses >= 3:
                        break
                    continue
            consecutive_misses = 0
            weekly = weekly.copy()
            weekly["gameweek"] = gameweek
            weekly["season_id"] = historical_season
            season_samples.append(weekly[[column for column in columns if column in weekly.columns]])
        if season_samples:
            season_history = pd.concat(season_samples, ignore_index=True)
            season_history = season_history.drop_duplicates(["player_name", "gameweek"], keep="last")
            write_parquet(
                season_history, season_path, source="dunkest_official_nba_plusvalenza_all_gameweeks",
                season_id=historical_season, through_gameweek=cutoff,
                gameweeks=int(season_history["gameweek"].nunique()),
            )
            samples.append(season_history)
    if not samples:
        logger.warning("No Dunkest NBA PLUS history found for IDs below %s", latest_candidate + 1)
        return pd.DataFrame(columns=columns)

    history = pd.concat(samples, ignore_index=True)
    history = history.drop_duplicates(["player_name", "season_id", "gameweek"], keep="last")
    for column in ("cr", "pdk", "plus", "min", "starter", "gameweek", "season_id"):
        if column in history:
            history[column] = pd.to_numeric(history[column], errors="coerce")
    history = history.dropna(subset=["player_name", "team_code", "cr", "pdk", "plus", "gameweek", "season_id"])
    history = history.loc[history["team_code"].astype(str).str.upper().isin(NBA_TEAM_CODES)]
    if not history.empty:
        write_parquet(
            history, anchor, source="dunkest_official_multiseason_nba_plusvalenza",
            season_ids=selected_seasons, through_gameweek=through_gameweek,
            sample_gameweeks="all_available",
        )
        logger.info(
            "Loaded Dunkest official NBA PLUS history: %s rows from seasons %s (%s gameweeks)",
            len(history), selected_seasons, history.groupby("season_id")["gameweek"].nunique().to_dict(),
        )
    return history


def get_dunkest_data(
    settings: Settings,
    gameweek: int | None = None,
    force_refresh: bool = False,
    use_live_market: bool = True,
) -> pd.DataFrame:
    gw = gameweek or settings.target_gameweek
    path = _processed(settings, f"dunkest_players_{settings.season_id}_gw{gw}.parquet")
    live_market_path = settings.data_path / "current_lineups_market.csv"
    has_live_market = use_live_market and live_market_path.exists()
    if has_live_market:
        _check_live_market_freshness(settings, live_market_path)
    if not force_refresh and not has_live_market and cache_valid(
        path, max_age_hours=settings.market_cache_max_age_hours
    ):
        df = read_parquet(path)
        if df is not None and {"official_plusvalenza", "actual_pdk", "gameweek_stats_available"}.issubset(df.columns):
            df = add_previous_credit_change(settings, df, gw)
            if use_live_market:
                save_player_credit_snapshot(settings, df, gw)
            return df
    df = dk_module.fetch_nba_season_players(settings)
    live = pd.DataFrame()
    if has_live_market:
        live = pd.read_csv(live_market_path)
        live.columns = [str(column).strip().lower() for column in live.columns]
        live = live[live.get("role", pd.Series(index=live.index, dtype=str)).astype(str).str.upper() != "HC"].copy()
        live["cr"] = pd.to_numeric(live.get("cr"), errors="coerce")
        live = live.dropna(subset=["player_name", "cr"])
        live_role = live["role"] if "role" in live else pd.Series("F", index=live.index)
        live["position"] = live_role.astype(str).str.upper().replace({"A": "F", "HC": "F"})
        live["pdk"] = float("nan")
        live["team_code"] = live.get("team", "").astype(str).str.upper()
        live_columns = [
            column for column in
            ("player_name", "cr", "position", "pdk", "team_code", "lineup_group", "status")
            if column in live.columns
        ]
        if df.empty:
            df = live[live_columns].copy()
        else:
            lookup_columns = [
                column for column in
                ("player_name", "cr", "position", "team_code", "lineup_group", "status")
                if column in live.columns
            ]
            lookup = live[lookup_columns].drop_duplicates("player_name", keep="last")
            df = df.merge(lookup, on="player_name", how="left", suffixes=("", "_lineups"))
            df["cr"] = df["cr_lineups"].fillna(df["cr"])
            for column in ("position", "team_code", "lineup_group", "status"):
                lineups_column = f"{column}_lineups"
                if lineups_column in df:
                    df[column] = df[lineups_column].fillna(df.get(column))
            df = df.drop(columns=[c for c in df.columns if c.endswith("_lineups")])
            df["role"] = df["position"]
    cr_updates = df[["player_name", "cr"]].copy()
    cr_updates["key"] = cr_updates["player_name"].map(player_key)
    current_week_stats = pd.DataFrame()
    for gw_i in range(max(1, gw - 5), gw + 1):
        gw_slice = dk_module.fetch_dunkest_gameweek_players(settings, gw_i)
        if gw_slice.empty:
            continue
        if gw_i == gw:
            current_week_stats = gw_slice
        if {"player_name", "cr"}.issubset(gw_slice.columns):
            weekly = gw_slice[["player_name", "cr"]].copy()
            weekly["key"] = weekly["player_name"].map(player_key)
            weekly["cr"] = pd.to_numeric(weekly["cr"], errors="coerce")
            weekly = weekly.loc[weekly["cr"].ge(settings.min_cr)].drop_duplicates("key", keep="last")
            updates = weekly.set_index("key")["cr"]
            cr_updates["cr"] = cr_updates["key"].map(updates).fillna(cr_updates["cr"])
    df = add_official_plusvalenza(df, current_week_stats)
    df = df.merge(
        cr_updates.drop(columns="key").rename(columns={"cr": "cr_latest"}),
        on="player_name",
        how="left",
        suffixes=("", "_dup"),
    )
    df["cr"] = df["cr_latest"].fillna(df["cr"])
    df = df.drop(columns=[c for c in df.columns if c.endswith("_dup") or c == "cr_latest"])
    if has_live_market:
        current_prices = live[["player_name", "cr"]].drop_duplicates("player_name", keep="last")
        df = df.merge(current_prices.rename(columns={"cr": "cr_lineups_live"}), on="player_name", how="left")
        df["cr"] = df["cr_lineups_live"].fillna(df["cr"])
        df = df.drop(columns="cr_lineups_live")
    if settings.impute_missing_cr:
        missing = df["cr"] < settings.min_cr
        df.loc[missing, "cr"] = (
            (df.loc[missing, "pdk"].astype(float) / 3.5)
            .clip(settings.min_cr, settings.max_cr)
            .fillna(settings.min_cr)
        )
    df = df[df["cr"] >= settings.min_cr].copy()
    gw_df = current_week_stats
    df["gameweek_stats_available"] = not gw_df.empty
    df["actual_pdk"] = float("nan")
    if not gw_df.empty:
        gw_copy = gw_df[["player_name", "pdk"]].copy()
        gw_copy["key"] = gw_copy["player_name"].map(player_key)
        gw_pdk = gw_copy.drop_duplicates("key", keep="last").set_index("key")["pdk"]
        df["key"] = df["player_name"].map(player_key)
        df["pdk_gw"] = df["key"].map(gw_pdk)
        df["actual_pdk"] = df["pdk_gw"].fillna(0.0)
        df["pdk"] = df["pdk_gw"].fillna(df["pdk"])
        df = df.drop(columns=["key", "pdk_gw"], errors="ignore")
    df["gameweek"] = gw
    df = add_previous_credit_change(settings, df, gw)
    if use_live_market:
        save_player_credit_snapshot(settings, df, gw)
    write_parquet(df, path, source="dunkest_api/stats/table", season_id=settings.season_id, gameweek=gw)
    return df


def save_injury_snapshot(
    settings: Settings, injuries: pd.DataFrame, gameweek: int
) -> None:
    """Archive the availability report used to make a pregame forecast."""
    if injuries.empty or "player_name" not in injuries.columns:
        return
    snapshot = injuries.copy()
    snapshot["gameweek"] = int(gameweek)
    path = _processed(
        settings, f"injuries_{settings.season_id}_gw{gameweek}.parquet"
    )
    write_parquet(
        snapshot.drop_duplicates("player_name", keep="last"),
        path,
        source="dunkest_pregame_availability_snapshot",
        season_id=settings.season_id,
        gameweek=gameweek,
        dunkest_turn=settings.target_dunkest_turn,
    )


def save_coach_market_snapshot(
    settings: Settings, coaches: pd.DataFrame, gameweek: int
) -> None:
    """Archive the coach prices and scheduled matchups used by a forecast."""
    required = {"coach", "team", "coach_cr"}
    if coaches.empty or not required.issubset(coaches.columns):
        return
    columns = [
        column for column in (
            "coach", "team", "coach_cr", "opponent", "opponent_coach",
            "opponent_coach_cr", "date", "giornata", "nba_game_id",
            "dunkest_gameweek", "dunkest_turn", "fixture_source",
        ) if column in coaches.columns
    ]
    snapshot = coaches[columns].copy()
    snapshot["team"] = snapshot["team"].astype(str).str.upper().str.strip()
    snapshot["coach_cr"] = pd.to_numeric(snapshot["coach_cr"], errors="coerce")
    if "opponent_coach_cr" in snapshot:
        snapshot["opponent_coach_cr"] = pd.to_numeric(
            snapshot["opponent_coach_cr"], errors="coerce"
        )
    snapshot = snapshot.dropna(subset=["coach", "team", "coach_cr"])
    snapshot["gameweek"] = int(gameweek)
    path = _processed(
        settings, f"coach_market_{settings.season_id}_gw{gameweek}.parquet"
    )
    write_parquet(
        snapshot.drop_duplicates("team", keep="last"),
        path,
        source="dunkest_pregame_coach_market_snapshot",
        season_id=settings.season_id,
        gameweek=gameweek,
    )


def get_injuries(settings: Settings, force_refresh: bool = False) -> pd.DataFrame:
    path = _processed(settings, "injuries.parquet")
    live_path = settings.data_path / "current_lineups_market.csv"
    live = pd.DataFrame()
    lineup_updated_names: set[str] = set()
    if live_path.exists():
        market = pd.read_csv(live_path)
        market.columns = [str(column).strip().lower() for column in market.columns]
        if "dunkest_turn" in market.columns:
            if settings.target_dunkest_turn is None:
                market = market.iloc[0:0]
            else:
                market = market[
                    pd.to_numeric(market["dunkest_turn"], errors="coerce")
                    == settings.target_dunkest_turn
                ]
        elif "gameweek" in market.columns:
            # Legacy scraper files mislabeled a Turno number as a Giornata.
            market = market.iloc[0:0]
        if {"player_name", "team", "status"}.issubset(market.columns):
            status = market["status"].astype(str).str.strip().str.upper()
            current = market.loc[status.isin({
                "OUT", "INJURED", "UNAVAILABLE", "INDISPONIBILE", "AVAILABLE"
            })].copy()
            lineup_updated_names = set(current["player_name"].astype(str).str.casefold())
            live = market.loc[status.isin({"OUT", "INJURED", "UNAVAILABLE", "INDISPONIBILE"}),
                              ["player_name", "team", "status"]].copy()
    # The scraper keeps a per-round injury snapshot, separate from the live
    # prices file. This remains available even after a later round is scraped.
    availability_path = settings.data_path / "lineups_availability.csv"
    if availability_path.exists():
        availability = pd.read_csv(availability_path)
        availability.columns = [str(column).strip().lower() for column in availability.columns]
        if {"player_name", "team", "status", "dunkest_turn"}.issubset(availability.columns):
            if settings.target_dunkest_turn is None:
                availability = availability.iloc[0:0]
            else:
                availability = availability[
                    pd.to_numeric(availability["dunkest_turn"], errors="coerce")
                    == settings.target_dunkest_turn
                ]
            if not availability.empty:
                lineup_updated_names.update(availability["player_name"].astype(str).str.casefold())
                live = pd.concat([live, availability[["player_name", "team", "status"]]], ignore_index=True)
    # Explicit user-confirmed overrides are kept separately because a later
    # browser scrape replaces the per-round availability snapshot.
    override_path = settings.data_path / "injury_overrides.csv"
    if override_path.exists():
        overrides = pd.read_csv(override_path)
        overrides.columns = [str(column).strip().lower() for column in overrides.columns]
        if {"player_name", "team", "status", "gameweek"}.issubset(overrides.columns):
            overrides = overrides[
                pd.to_numeric(overrides["gameweek"], errors="coerce") == settings.target_gameweek
            ]
            if not overrides.empty:
                lineup_updated_names.update(overrides["player_name"].astype(str).str.casefold())
                live = pd.concat([live, overrides[["player_name", "team", "status"]]], ignore_index=True)
    # When Lineups has already provided a turn-specific availability snapshot,
    # treat it as authoritative for this turn and skip the abbreviated web
    # injuries page (e.g. "S. Curry") which over-excludes via surname matching.
    lineups_authoritative = not live.empty and settings.target_dunkest_turn is not None
    if not force_refresh and cache_valid(path, max_age_hours=6) and not lineups_authoritative:
        df = read_parquet(path)
        if df is not None and (not df.empty or not live.empty):
            if "player_name" not in df.columns:
                df = pd.DataFrame(columns=["player_name", "status", "team"])
            if lineup_updated_names and "player_name" in df:
                df = df[~df["player_name"].astype(str).str.casefold().isin(lineup_updated_names)]
            return pd.concat([df, live], ignore_index=True).drop_duplicates("player_name", keep="last")
    if lineups_authoritative:
        merged = live.drop_duplicates("player_name", keep="last")
        write_parquet(merged, path, source="lineups_availability", gameweek=settings.target_gameweek)
        return merged
    cached = read_parquet(path)
    try:
        df = dk_module.scrape_injuries(settings)
    except Exception:
        if live.empty and (cached is None or cached.empty):
            raise
        df = pd.DataFrame()
    if "player_name" not in df.columns:
        df = pd.DataFrame(columns=["player_name", "status", "team"])
    if lineup_updated_names and "player_name" in df:
        df = df[~df["player_name"].astype(str).str.casefold().isin(lineup_updated_names)]
    if df.empty and live.empty and cached is not None and not cached.empty:
        import warnings

        warnings.warn(
            "La pagina infortuni ha restituito una lista vuota; mantengo l'ultimo archivio "
            "valido invece di interpretare il risultato come tutti disponibili.",
            RuntimeWarning,
            stacklevel=2,
        )
        df = cached
    df = pd.concat([df, live], ignore_index=True).drop_duplicates("player_name", keep="last")
    if not df.empty:
        write_parquet(df, path, source="dunkest_html/infortuni")
    return df


def get_player_data(settings: Settings, force_refresh: bool = False) -> pd.DataFrame:
    path = _processed(settings, f"player_game_logs_{settings.season}.parquet")
    if not force_refresh and cache_valid(path, max_age_hours=24):
        metadata = read_cache_metadata(path) or {}
        cache_source = metadata.get("source")
        verified_collection = metadata.get("collection_complete") is True
        df = None
        if (
            cache_source != "nba_api/playergamelog" or verified_collection
        ):
            df = read_parquet(path)
        if df is not None:
            synthetic = (
                df.get("data_source", pd.Series("", index=df.index))
                .astype(str)
                .eq("synthetic_dunkest_market")
                .any()
                or df.get("OPPONENT", pd.Series("", index=df.index))
                .astype(str)
                .eq("OPP")
                .any()
            )
            if synthetic and not settings.allow_synthetic_logs:
                if not settings.use_nba_api_logs:
                    raise RuntimeError(
                        f"La cache {path} contiene log sintetici. Raccogli log NBA reali; "
                        "per usare esplicitamente il fallback imposta allow_synthetic_logs: true."
                    )
                # Ignore the synthetic cache and try to replace it with real logs.
            else:
                if synthetic:
                    import warnings

                    warnings.warn(
                        f"Uso cache di log sintetici: {path}. Previsioni non basate su risultati NBA reali.",
                        RuntimeWarning,
                        stacklevel=2,
                    )
                return df
    dk = dk_module.fetch_nba_season_players(settings)
    if not dk.empty:
        priority_column = "cr" if "cr" in dk.columns else "pdk"
        ordered = dk.assign(_priority=pd.to_numeric(dk[priority_column], errors="coerce"))
        names = ordered.sort_values("_priority", ascending=False, na_position="last")["player_name"].astype(str).tolist()
    else:
        names = None
    df = pd.DataFrame()
    collection_error: Exception | None = None
    if settings.use_nba_api_logs:
        try:
            df = nba.fetch_player_game_logs(settings, player_names=names)
            report = df.attrs.get("collection_report")
            if report is None or not report.get("collection_complete", False):
                collection_error = RuntimeError(
                    "NBA player game-log collection is incomplete: "
                    f"{report or 'collector did not provide a completeness report'}"
                )
                df = pd.DataFrame()
        except Exception as exc:
            collection_error = exc
            df = pd.DataFrame()
    if df.empty and dk.empty and collection_error is not None:
        raise RuntimeError(f"NBA player game-log collection failed: {collection_error}") from collection_error
    if df.empty and not dk.empty:
        if not settings.allow_synthetic_logs:
            raise RuntimeError(
                "Log NBA reali completi non disponibili; il fallback sintetico è disattivato. "
                "Riprova con una cache player_game_logs valida oppure abilita "
                "allow_synthetic_logs solo se accetti previsioni basate su dati simulati. "
                f"Errore raccolta: {collection_error}"
            ) from collection_error
        from dunkest.data.nba.fallback_logs import synthetic_logs_from_dunkest

        import warnings

        warnings.warn(
            "NBA game logs unavailable; using synthetic logs. Predictions and backtests "
            "are based on synthetic history.", RuntimeWarning, stacklevel=2
        )
        fallback = dk
        if settings.max_player_log_entries > 0:
            order_column = "cr" if "cr" in dk.columns else "pdk"
            fallback = dk.assign(_priority=pd.to_numeric(dk[order_column], errors="coerce"))
            fallback = fallback.sort_values("_priority", ascending=False, na_position="last").head(
                settings.max_player_log_entries
            ).drop(columns="_priority")
        df = synthetic_logs_from_dunkest(fallback)
        df["data_source"] = "synthetic_dunkest_market"
        write_parquet(df, path, source="synthetic_dunkest_market", season=settings.season)
        return df
    if not df.empty:
        df["data_source"] = "nba_api/playergamelog"
    report = df.attrs.get("collection_report", {})
    write_parquet(
        df,
        path,
        source="nba_api/playergamelog",
        season=settings.season,
        **report,
    )
    return df


def get_team_data(settings: Settings, force_refresh: bool = False) -> pd.DataFrame:
    path = _processed(settings, f"team_game_logs_{settings.season}.parquet")
    if not force_refresh and cache_valid(path, max_age_hours=24):
        metadata = read_cache_metadata(path) or {}
        cache_source = metadata.get("source")
        verified_collection = metadata.get("collection_complete") is True
        df = None
        if (
            cache_source != "nba_api/teamgamelog" or verified_collection
        ):
            df = read_parquet(path)
        if df is not None:
            return df
    if not settings.use_nba_api_logs:
        write_parquet(pd.DataFrame(), path, source="skipped")
        return pd.DataFrame()
    df = nba.fetch_team_game_logs(settings)
    report = df.attrs.get("collection_report")
    if report is None or not report.get("collection_complete", False):
        raise RuntimeError(
            "NBA team game-log collection is incomplete: "
            f"{report or 'collector did not provide a completeness report'}"
        )
    write_parquet(df, path, source="nba_api/teamgamelog", **report)
    return df


def get_schedule(settings: Settings, force_refresh: bool = False) -> pd.DataFrame:
    path = _processed(settings, f"schedule_{settings.season}.parquet")
    if not force_refresh and cache_valid(path, max_age_hours=24):
        df = read_parquet(path)
        if df is not None:
            return df
    if not settings.use_nba_api_logs:
        write_parquet(pd.DataFrame(), path, source="skipped")
        return pd.DataFrame()
    df = nba.fetch_schedule(settings)
    write_parquet(df, path, source="nba_api/leaguegamefinder")
    return df


def get_future_schedule(settings: Settings, force_refresh: bool = False) -> pd.DataFrame:
    # v2 keeps the NBA week label semantically explicit and avoids loading a
    # cached frame whose WEEK_NUMBER column may have been confused with GW.
    path = _processed(settings, f"future_regular_schedule_{settings.season}_v2.parquet")
    if not force_refresh and cache_valid(path, max_age_hours=24):
        df = read_parquet(path)
        if df is not None and "NBA_WEEK_NUMBER" in df:
            return df
    df = nba.fetch_future_schedule(settings)
    write_parquet(df, path, source="nba_api/scheduleleaguev2", season=settings.season)
    return df


def _historical_coach_scores(
    settings: Settings, coaches: dict[str, tuple[str, float]]
) -> dict[str, float]:
    """Estimate coach PDK from completed prior-season team results for G1."""
    prior = copy(settings)
    prior.season = settings.feature_season
    try:
        games = nba.fetch_schedule(prior)
    except Exception:
        return {}
    required = {"HOME_TEAM", "AWAY_TEAM", "PTS", "PLUS_MINUS"}
    if games.empty or not required.issubset(games.columns):
        return {}

    scores: dict[str, list[float]] = {}
    for _, game in games.iterrows():
        home = str(game["HOME_TEAM"]).strip().upper()
        away = str(game["AWAY_TEAM"]).strip().upper()
        if home not in coaches or away not in coaches:
            continue
        home_pts = pd.to_numeric(game["PTS"], errors="coerce")
        margin = pd.to_numeric(game["PLUS_MINUS"], errors="coerce")
        if pd.isna(home_pts) or pd.isna(margin):
            continue
        away_pts = float(home_pts) - float(margin)
        for team, opponent, points, opponent_points in (
            (home, away, float(home_pts), away_pts),
            (away, home, away_pts, float(home_pts)),
        ):
            coach_cr = coaches[team][1]
            opponent_cr = coaches[opponent][1]
            score = coach_points_from_game(points, opponent_points, coach_cr, opponent_cr)
            scores.setdefault(team, []).append(score)
    return {team: sum(values) / len(values) for team, values in scores.items() if values}


def get_coach_data(
    settings: Settings,
    gameweek: int | None = None,
    force_refresh: bool = False,
    coach_market: pd.DataFrame | None = None,
) -> pd.DataFrame:
    gw = gameweek or settings.target_gameweek
    # Bump the cache key after changing gameweek-specific schedule selection;
    # otherwise an older cache can keep returning an opponent from another GW.
    path = _processed(settings, f"coaches_{settings.season_id}_gw{gw}_v3.parquet")
    market_path = settings.data_path / "current_lineups_market.csv"
    has_live_market = coach_market is None and market_path.exists()
    if has_live_market:
        _check_live_market_freshness(settings, market_path)
    if not force_refresh and coach_market is None and not has_live_market and cache_valid(
        path, max_age_hours=settings.market_cache_max_age_hours
    ):
        df = read_parquet(path)
        if df is not None and not df.empty:
            return df

    coach_map: dict[str, str] = {}
    exact_coaches: dict[str, tuple[str, float]] = {}
    if coach_market is None:
        if market_path.exists():
            live = pd.read_csv(market_path)
            live.columns = [str(column).strip().lower() for column in live.columns]
            if {"player_name", "cr", "team", "role"}.issubset(live.columns):
                live = live[live["role"].astype(str).str.upper().eq("HC")]
                for _, item in live.iterrows():
                    cr = pd.to_numeric(item["cr"], errors="coerce")
                    if pd.notna(cr) and float(cr) >= settings.min_cr:
                        exact_coaches[str(item["team"]).upper()] = (str(item["player_name"]), float(cr))
        if not exact_coaches:
            coach_map_path = settings.root / "config" / "nba_coaches_2026.yaml"
            with coach_map_path.open(encoding="utf-8") as f:
                coach_map = yaml.safe_load(f) or {}

    # A Dunkest coach matchup is never inferred from NBA_WEEK_NUMBER. The
    # versioned bridge is the sole source of Giornata/Turno/eligibility.
    schedule = get_fixture_mapping(settings, gw)
    schedule = schedule.loc[schedule["fantasy_eligible"].eq(True)].copy()
    schedule = schedule.rename(
        columns={"game_datetime_utc": "GAME_DATE", "home_team": "HOME_TEAM", "away_team": "AWAY_TEAM", "nba_game_id": "NBA_GAME_ID"}
    )
    schedule["GAME_DATE"] = pd.to_datetime(schedule.get("GAME_DATE"), errors="coerce", utc=True)
    if schedule.empty:
        schedule = pd.DataFrame(columns=["GAME_DATE", "HOME_TEAM", "AWAY_TEAM", "NBA_GAME_ID"])

    if coach_market is not None and not coach_market.empty:
        required = {"coach", "team", "coach_cr"}
        if not required.issubset(coach_market.columns):
            raise ValueError("Il listino coach deve contenere coach, team e coach_cr.")
        for _, row in coach_market.iterrows():
            team = str(row["team"]).strip().upper()
            name = str(row["coach"]).strip()
            cr = pd.to_numeric(row["coach_cr"], errors="coerce")
            if team and name and pd.notna(cr) and float(cr) >= settings.min_cr:
                exact_coaches[team] = (name, float(cr))

    rows: list[dict] = []
    recent = schedule.sort_values("GAME_DATE").tail(60)
    for _, game in recent.iterrows():
        for team, opp in ((game["HOME_TEAM"], game["AWAY_TEAM"]), (game["AWAY_TEAM"], game["HOME_TEAM"])):
            team, opp = str(team).upper(), str(opp).upper()
            coach = exact_coaches.get(team, (coach_map.get(team, ""), float("nan")))
            opp_coach = exact_coaches.get(opp, (coach_map.get(opp, ""), float("nan")))
            rows.append(
                {
                    "giornata": gw,
                    "dunkest_gameweek": gw,
                    "dunkest_turn": game.get("dunkest_turn"),
                    "nba_game_id": game.get("NBA_GAME_ID"),
                    "fixture_source": game.get("source"),
                    "date": pd.Timestamp(game["GAME_DATE"]).date().isoformat(),
                    "coach": coach[0],
                    "team": team,
                    "opponent": opp,
                    "coach_cr": coach[1],
                    "opponent_coach": opp_coach[0],
                    "opponent_coach_cr": opp_coach[1],
                }
            )
    df = pd.DataFrame(
        rows,
        columns=[
            "giornata", "date", "coach", "team", "opponent", "coach_cr",
            "opponent_coach", "opponent_coach_cr", "dunkest_turn", "nba_game_id", "fixture_source",
        ],
    )
    if not df.empty:
        # One score-bearing game per team per Giornata: keep the earliest mapped fixture.
        df = df.sort_values(["date", "nba_game_id"], kind="stable").drop_duplicates(
            subset=["team"], keep="first"
        )
    cr_table = dk_module.fetch_coach_cr_table(settings, gw) if coach_market is None else pd.DataFrame()
    if not cr_table.empty and "team_code" in cr_table.columns:
        cr_by_team = cr_table.groupby("team_code")["cr"].median()
        df["coach_cr"] = df["team"].map(cr_by_team).fillna(df["coach_cr"])

    # Missing coach quotes are excluded rather than fabricated from player prices.
    df = df.dropna(subset=["coach_cr", "opponent_coach_cr"])
    df = df[(df["coach"] != "") & (df["opponent_coach"] != "")]
    if exact_coaches:
        covered = set(df["team"].astype(str).str.upper())
        if not covered:
            # Before the new schedule is published, use each team's completed
            # prior-season coach PDK as the opener forecast.
            prior_scores = _historical_coach_scores(settings, exact_coaches)
            df = pd.DataFrame(
                [
                    {
                        "giornata": gw,
                        "date": "",
                        "coach": name,
                        "team": team,
                        "opponent": "",
                        "coach_cr": cr,
                        "opponent_coach": "",
                        "opponent_coach_cr": float("nan"),
                        "prior_coach_pdk": prior_scores.get(team, float("nan")),
                    }
                    for team, (name, cr) in exact_coaches.items()
                ]
            )
    write_parquet(df, path, source="coach_lineup_market+schedule", gameweek=gw)
    return df
